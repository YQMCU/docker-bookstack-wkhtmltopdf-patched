<?php

namespace BookStack\Access\Oidc;

class OidcInvalidKeyException extends \Exception
{
}
