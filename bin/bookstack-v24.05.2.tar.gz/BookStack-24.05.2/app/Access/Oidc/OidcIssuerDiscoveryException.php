<?php

namespace BookStack\Access\Oidc;

use Exception;

class OidcIssuerDiscoveryException extends Exception
{
}
