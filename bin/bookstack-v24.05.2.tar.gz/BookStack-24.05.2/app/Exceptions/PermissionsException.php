<?php

namespace BookStack\Exceptions;

use Exception;

class PermissionsException extends Exception
{
}
