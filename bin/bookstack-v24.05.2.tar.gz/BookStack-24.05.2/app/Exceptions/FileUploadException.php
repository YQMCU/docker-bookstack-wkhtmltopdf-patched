<?php

namespace BookStack\Exceptions;

class FileUploadException extends PrettyException
{
}
